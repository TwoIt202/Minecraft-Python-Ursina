from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.texture_importer import load_texture
from perlin_noise import PerlinNoise
from ursina.shaders import basic_lighting_shader
import random
import mcoms


app = Ursina()
player = FirstPersonController()



spawn_x = int(player.x)
spawn_y = int(player.y)
spawn_z = int(player.z)

biomes = ["Meadow", "Forest"]
biome = random.choice(biomes)
bio = 5

chunk_radius = 0


def load_asset(texture, type):
      return load_texture(f"assets/{type}/{texture}.png")

def audio(name, folder):
      return f"assets/audio/{folder}/{name}.mp3"

# Sky
sky = load_asset("sky", "img")

grass_blocks = []

# textures
grass = load_asset("grass", "textures")
dirt = load_asset("dirt", "textures")
oak = load_asset("oak", "textures")
sand = load_asset("sand", "textures")
stone = load_asset("stone", "textures")
oak_plank = load_asset("oak_plank", "textures")
leaves = load_asset("leaves", "textures")
cobblestone = load_asset("cobblestone", "textures")
water = load_asset("water", "textures")

all_blocks = []

# audio
grass_audio = []
sand_audio = []
stone_audio = []
wood_audio = []

grass_audio.append(audio("grass1", "grass"))
grass_audio.append(audio("grass2", "grass"))
grass_audio.append(audio("grass3", "grass"))

sand_audio.append(audio("sand1", "sand"))
sand_audio.append(audio("sand2", "sand"))
sand_audio.append(audio("sand3", "sand"))

stone_audio.append(audio("stone1", "stone"))
stone_audio.append(audio("stone2", "stone"))
stone_audio.append(audio("stone3", "stone"))

wood_audio.append(audio("wood1", "wood"))
wood_audio.append(audio("wood2", "wood"))
wood_audio.append(audio("wood3", "wood"))

leaven = audio("cloth1", "cloth")

resource_packs = os.listdir("resource_packs")

for pack in resource_packs:

      mods = os.listdir(f"resource_packs/{pack}")


      if "textures" in mods:

            textures = os.listdir(f"resource_packs/{pack}/textures")

            for texture in textures:

                  filename = texture.rstrip(".png")
                  exec(f"{filename} = load_texture(f'resource_packs/{pack}/textures/{texture}')")


      
      if "sounds" in mods:

            sounds = os.listdir(f"resource_packs/{pack}/sounds")

            for sound in sounds:

                  snds = os.listdir(f"resource_packs/{pack}/sounds/{sound}")

                  for snd in snds:
                        filename = snd.rstrip(".mp3")
                        exec(f"{snd}_audio = []")

                        exec(f"{snd}_audio.append(audio('{filename}', '{sound}'))")



current_texture = grass






def input(key):
      if key == "right shift down":
            player.speed = 8


class Hand(Entity):
      def __init__(self):
            super().__init__(
                  parent=camera.ui,
                  model='cube',
                  texture='white_cube',
                  scale=.5,
                  rotation = Vec3(-85, 145, 0),
                  position=Vec2(0.4, -0.5)
            )

      def update(self):
            self.texture = current_texture




                  
class BlockUI(Entity):
      def __init__(self):
            super().__init__(
                  parent=camera.ui,
                  model='cube',
                  scale=0.1,
                  texture=current_texture,
                  position=Vec2(-0.8, 0.4)
            )

      def update(self):
            self.texture = current_texture





class Sky(Entity):
      def __init__(self):
            super().__init__(
                  parent=scene,
                  model='sphere',
                  scale=150,
                  texture=sky,
                  double_sided=True
            )


class Block(Button):
      def __init__(self, position=(0, 0, 0), texture=current_texture):

            if position in all_blocks:
                  return

            super().__init__(
                  parent=scene,
                  position=position,
                  model='cube',
                  origin_y=.5,
                  texture=texture,
                  doublew_sided=True,
                  color=color.color(0, 0, 255),
                  highlight_color=color.gray,
            )

            all_blocks.append(position)
      
      def input(self, key):
            if self.hovered:
                  if key == "right mouse down":

                        all_blocks.append(self.position)

                        if self.position+mouse.normal in all_blocks:
                              return

                        if current_texture == grass or current_texture == dirt:
                              block = Block(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(grass_audio))

                        if current_texture == sand:
                              block = Block(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(sand_audio))

                        if current_texture == stone:
                              block = Block(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(stone_audio))

                        if current_texture == cobblestone:
                              block = Block(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(stone_audio)) 

                        
                        if current_texture == oak or current_texture == oak_plank:
                              block = Block(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(wood_audio))

                        if current_texture == leaves:
                              block = Block(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(leaven)

                        else:
                              block = Block(position=self.position+mouse.normal, texture=current_texture)

                        

                        
                  if key == "left mouse down":

                        all_blocks.remove(self.position)

                        if self.texture == grass:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(grass_audio))

                        elif self.texture == dirt:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(grass_audio))

                        elif self.texture == sand:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(sand_audio))

                        elif self.texture == oak or self.texture == oak_plank:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(wood_audio))

                        elif self.texture == stone or self.texture == cobblestone:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(stone_audio))

                        elif self.texture == leaves:
                              destroy(self)
                              mcoms.PlayAudio(leaven)

                        else:
                              destroy(self)

class Water(Entity):
      def __init__(self, position=(0, 0, 0), texture=water):
            super().__init__(
                  parent=scene,
                  position=position,
                  model='cube',
                  origin_y=.5,
                  texture=texture,
                  doublew_sided=True,
                  color=color.color(0, 0, 255),
                  highlight_color=color.gray,
            )


class Trees:
    def __init__(self, x, y, z):
        
        

        self.length = 5

        for y_b in range(self.length):

            
            b = Block(position=(x, y+y_b, z), texture=oak)

        y = y + y_b

        b = Block(position=(x+1, y, z), texture=leaves)
        b = Block(position=(x-1, y, z), texture=leaves)

        b = Block(position=(x, y, z+1), texture=leaves)
        b = Block(position=(x, y, z-1), texture=leaves)



        b = Block(position=(x+1, y+1, z), texture=leaves)
        b = Block(position=(x-1, y+1, z), texture=leaves)

        b = Block(position=(x, y+1, z+1), texture=leaves)
        b = Block(position=(x, y+1, z-1), texture=leaves)



        b = Block(position=(x+2, y+1, z), texture=leaves)
        b = Block(position=(x-2, y+1, z), texture=leaves)

        b = Block(position=(x, y+1, z+2), texture=leaves)
        b = Block(position=(x, y+1, z-2), texture=leaves)



        b = Block(position=(x+1, y+1, z+1), texture=leaves)
        b = Block(position=(x-1, y+1, z+1), texture=leaves)

        b = Block(position=(x+1, y+1, z+1), texture=leaves)
        b = Block(position=(x-1, y+1, z-1), texture=leaves)



        b = Block(position=(x+1, y+2, z), texture=leaves)
        b = Block(position=(x-1, y+2, z), texture=leaves)

        b = Block(position=(x, y+2, z+1), texture=leaves)
        b = Block(position=(x, y+2, z-1), texture=leaves)



        b = Block(position=(x, y+3, z), texture=leaves)



class Chunk():

      def __init__(self, xs=0, ys=0, zs=0):

            global chunk_radius, grass_blocks

            chunk_radius += 15

            seed = 100
            noise = PerlinNoise(octaves=2,seed=seed)

            seed_cave = random.randint(1,1000000)
            noise_cave = PerlinNoise(octaves=1,seed=seed_cave)

            for z in range(32):
                  for x in range(32):
                        y_n = noise([x * 0.02, z * 0.02])
                        y = math.floor(y_n * 23)


                        if y > 1:
                              block = Block((x, y, z), stone)

                        else:
                              block = Block((x, y, z))

                              grass_blocks.append([x, y, z])

            for i in range(4):
                  pos = random.choice(grass_blocks)
                  tree = Trees(pos[0], pos[1]+1, pos[2])



                        



           


      





def update():
      global current_texture, spawn_x, spawn_z, biome, bio, biomes

      if held_keys['1']:
            current_texture = grass
      if held_keys['2']:
            current_texture = dirt
      if held_keys['3']:
            current_texture = oak
      if held_keys['4']:
            current_texture = sand
      if held_keys['5']:
            current_texture = stone
      if held_keys['6']:
            current_texture = oak_plank
      if held_keys['7']:
            current_texture = water
      if held_keys['8']:
            current_texture = cobblestone




      #if int(player.x - spawn_x) == 5:
            #spawn_x = player.x

            #chunk = Chunk(int(spawn_x + 10))





chunk = Chunk()


sky_text = Sky()
blockUI = BlockUI()
hand = Hand()





app.run()