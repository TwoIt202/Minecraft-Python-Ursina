from turtle import position
from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController


app = Ursina()


def load_asset(texture, folder):
      return load_texture(f"assets/{folder}/{texture}.png")


grass = load_asset("grass", "models")
stone = load_asset("stone", "models")
sky = load_asset("sky", "img")

current_texture = grass


def update():
      global current_texture

      if held_keys['1']:
            current_texture = grass
      if held_keys['2']:
            current_texture = stone







class Sky(Entity):
      def __init__(self):
            super().__init__(
                  parent=scene,
                  model='sphere',
                  scale=150,
                  texture=sky,
                  double_sided=True
            )




class Voxel(Button):
      def __init__(self, position=(0, 0, 0), texture=None):
            super().__init__(
                  parent = scene,
                  position=position,
                  model='cube',
                  origin_y = .5,
                  texture=texture,
                  color=color.color(0, 0, 255),
                  highlight_color=color.gray
            )

      
      def input(self, key):
            if self.hovered:
                  if key == "right mouse down":
                        block = Voxel(position=self.position+mouse.normal, texture=current_texture)
                  if key == "left mouse down":
                        destroy(self)


class BlockUI(Entity):
      def __init__(self):
            super().__init__(
                  parent=camera.ui,
                  model='cube',
                  scale=0.1,
                  texture=current_texture,
                  position=Vec2(-0.8, 0.4)
            )

      def update(self):
            self.texture = current_texture







for z in range(25):
      for x in range(25):
            voxel = Voxel((x, 0, z), texture=grass)

player = FirstPersonController()
skyRun = Sky()
blockUI = BlockUI()

app.run()