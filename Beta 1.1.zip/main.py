from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.texture_importer import load_texture
from ursina.shaders import basic_lighting_shader

from wincom import write, read, file, folder
from perlin_noise import PerlinNoise
from random import randint
from os import listdir, system

from minecraft.blocks.Grass import Grass
from minecraft.blocks.Stone import Stone
from minecraft.blocks.Dirt import Dirt
from minecraft.blocks.Oak_log import Oak_log
from minecraft.blocks.Oak_plank import Oak_plank
from minecraft.blocks.Barrier import Barrier

from minecraft.world.Sky import Sky
from minecraft.world.Water import Water

from minecraft.items.Hand import Hand

system("pip install ursina")
system("pip install wincom")
system("pip install perlin_noise")

world = input("Name of World: ")
worlds = listdir('saves')

if world == "x64":
    world = "x64 World (For powerful PCs)"
    
if world not in worlds:

    folder('saves/'+world)
    file(f'saves/{world}/block.data')
    write(f'saves/{world}/player.data', '[0.0, 0.0, 0.0]')
    write(f'saves/{world}/block.data', '[]')




app = Ursina()
player = FirstPersonController()

def str_to_list(l):
    l = eval(f'{l}')
    return l

cords = str_to_list(read(f'saves/{world}/player.data'))

player.x, player.y, player.z = cords
print(cords)

player.speed = 5
normal_speed = 5

shift_click = 0

write('invent', 'grass\ngrass')

def update():

    global sprint

    if held_keys['space']:
        player.y += 0.1

    if held_keys['shift']:
        player.y -= 0.1

    if held_keys['control']: # кнопка быстрого бега
        global shift_click

        if shift_click % 1 == 0:
            player.speed = normal_speed + 7 # увеличиваем скорость при нажатии
            shift_click += 1
        else:
            player.speed = normal_speed
            shift_click += 1

    if held_keys['1']:
        write('invent', 'grass\ngrass')

    if held_keys['2']:
        write('invent', 'dirt\ngrass')

    if held_keys['3']:
        write('invent', 'stone\nstone')

    if held_keys['4']:
        write('invent', 'oak_log\nwood')

    if held_keys['5']:
        write('invent', 'oak_plank\nwood')

    write(f'saves/{world}/player.data', f'[{player.x}, {player.y}, {player.z}]')

    




seed = random.randint(1, 999999999)
noise = PerlinNoise(octaves=2,seed=seed)



if world not in worlds:

    fl = randint(5, 22)

    for z in range(16):
        for x in range(16):
            y_n = noise([x * 0.02, z * 0.02])
            y = math.floor(y_n * fl)


            if y > 1:
                block = Stone((x, y, z), world, generation=True)
            
            elif y < 0 and y > -3:
                water = Water((x, y, z), world, generation=True)

            else:
                block = Grass((x, y, z), world, generation=True)

            

else:
    for cords in str_to_list(read(f'saves/{world}/block.data')):
        x, y, z, typ = cords
        block = eval(f"{typ}(position=({x}, {y}, {z}), world='{world}', generation=False)")



sky = Sky()
hand = Hand()

player.gravity = 0.0
app.run()

