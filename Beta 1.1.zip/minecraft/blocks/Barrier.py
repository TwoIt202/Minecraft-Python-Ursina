from ursina import *

from os import listdir
from random import choice
from wincom import read

from minecraft.blocks.Block import Block

app = Ursina()

barrier = load_texture("assets/textures/blocks/barrier.png")
sounds = listdir('assets/audio/blocks/stone')
s='stone'



class Barrier(Block):
    
    def __init__(self, position, world, generation=False, s=s):

        super().__init__(
            positions=position,
            textures=barrier,
            sounds=sounds,
            world=world,
            typ='Stone',
            generation=generation,
            s=s,
            copythis=False
        )
