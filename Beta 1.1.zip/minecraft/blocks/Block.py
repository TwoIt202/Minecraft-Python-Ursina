from ursina import *
from ursina.shaders import basic_lighting_shader

from wincom import read, write
from os import listdir
from random import choice

app = Ursina()


def str_to_list(l):
    l = eval(f'{l}')
    return l


def addm(mass, typ, world):

    x, y, z = mass

    blocks = str_to_list(read(f'saves/{world}/block.data'))
    blocks.append([x, y, z, typ])
    write(f'saves/{world}/block.data', str(blocks))


def rem(mass, typ, world):

    x, y, z = mass

    

    blocks = str_to_list(read(f'saves/{world}/block.data'))


    blocks.remove([x, y, z, typ])
    write(f'saves/{world}/block.data', str(blocks))


class Block(Button):
    
    def __init__(self, sounds, textures, positions, world, typ, generation=False, s=None, copythis=True):


        self.sounds = sounds
        self.textures = textures
        self.positions = positions
        self.world = world
        self.typ = typ

        self.sound = s

        self.generation = generation
        self.gener = str_to_list(read('saves/'+self.world+'/block.data'))

        self.copythis = copythis

        if self.positions not in self.gener:
            if generation is True:
                addm(positions, self.typ, self.world)
            

        

            super().__init__(
                parent=scene,
                model='cube',
                position=self.positions,
                texture=self.textures,
                origin_y=.5,
                color=color.white,
                highlight_color=color.gray,
                shader=basic_lighting_shader
            )

    def input(self, key):

        if self.hovered:
                
            if key == 'right mouse down':

                

                n = read('invent').split('\n')
                tt = load_texture(f'assets/textures/blocks/{n[0]}.png')
                ss = listdir(f'assets/audio/blocks/{n[1]}')
                sound = choice(ss)

                addm(self.position + mouse.normal, n[0].capitalize(), self.world)
            
        
                block = Block(positions=self.position + mouse.normal, textures=tt, sounds=ss, world=self.world, typ=n[0].capitalize(), generation=False, copythis=True)
                invoke(Audio, sound)


            if key == 'left mouse down':            
                rem(self.position, self.typ, self.world)
                destroy(self)
                invoke(Audio, choice(self.sounds))


            
            if key == 'middle mouse down':

                if self.copythis is True:
                    write('invent', f'{self.typ.lower()}\n{self.sound}')