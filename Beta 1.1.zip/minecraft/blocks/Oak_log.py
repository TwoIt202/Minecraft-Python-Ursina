from ursina import *

from os import listdir
from random import choice
from wincom import read

from minecraft.blocks.Block import Block

app = Ursina()

oak = load_texture("assets/textures/blocks/oak_log.png")
sounds = listdir('assets/audio/blocks/wood')
s='wood'


class Oak_log(Block):
    
    def __init__(self, position, world, generation=False, s=s):

        super().__init__(
            positions=position,
            textures=oak,
            sounds=sounds,
            world=world,
            typ='Oak_log',
            generation=generation,
            s=s
        )



    
