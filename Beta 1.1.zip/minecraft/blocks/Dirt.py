from ursina import *

from os import listdir
from random import choice
from wincom import read

from minecraft.blocks.Block import Block

app = Ursina()

dirt = load_texture("assets/textures/blocks/dirt.png")
sounds = listdir('assets/audio/blocks/grass')
s='grass'



class Dirt(Block):
    
    def __init__(self, position, world, generation=False, s=s):

        super().__init__(
            positions=position,
            textures=dirt,
            sounds=sounds,
            world=world,
            typ='Dirt',
            generation=generation,
            s=s
        )



    
