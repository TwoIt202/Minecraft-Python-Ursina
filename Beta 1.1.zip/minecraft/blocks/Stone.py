from ursina import *

from os import listdir
from random import choice
from wincom import read

from minecraft.blocks.Block import Block

app = Ursina()

stone = load_texture("assets/textures/blocks/stone.png")
sounds = listdir('assets/audio/blocks/stone')
s='stone'



class Stone(Block):
    
    def __init__(self, position, world, generation=False, s=s):

        super().__init__(
            positions=position,
            textures=stone,
            sounds=sounds,
            world=world,
            typ='Stone',
            generation=generation,
            s=s
        )
