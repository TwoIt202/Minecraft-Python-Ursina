from ursina import *
from wincom import read

app = Ursina()

class Hand(Entity):
      def __init__(self):
            super().__init__(
                  parent=camera.ui,
                  model='cube',
                  texture=load_texture(f"assets/textures/blocks/grass.png"),
                  scale=.5,
                  rotation = Vec3(-85, 145, 0),
                  position=Vec2(0.4, -0.5)
            )

      def update(self):
            
            texture = read('invent').split('\n')
            self.texture = load_texture(f"assets/textures/blocks/{texture[0]}.png")
            