from ursina import *

app = Ursina()

sky = load_texture("assets/textures/blocks/sky.png")

class Sky(Entity):
    def __init__(self):
        super().__init__(
            parent=scene,
            model='sphere',
            scale=500,
            texture=sky,
            double_sided=True
        )