from ursina import *
from minecraft.blocks.Block import addm

app = Ursina()
water = load_texture("assets/textures/blocks/water.png")

class Water(Entity):
      def __init__(self, position, world, generation=False, s=None):
            super().__init__(
                  parent=scene,
                  position=position,
                  model='cube',
                  origin_y=.5,
                  texture=water,
                  doublew_sided=True,
                  color=color.color(0, 0, 255),
                  highlight_color=color.gray,
            )

            if generation is True:
                addm(position, 'Water', world)