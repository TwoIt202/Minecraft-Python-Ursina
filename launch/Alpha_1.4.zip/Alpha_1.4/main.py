from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.texture_importer import load_texture
import random
import mcoms

app = Ursina()




def load_asset(texture, type):
      return load_texture(f"assets/{type}/{texture}.png")

def audio(name, folder):
      return f"versions/Alpha_1.4/assets/audio/{folder}/{name}.mp3"

# Sky
sky = load_asset("sky", "img")



# models
grass = load_asset("grass", "models")
dirt = load_asset("dirt", "models")
oak = load_asset("oak", "models")
sand = load_asset("sand", "models")
stone = load_asset("stone", "models")
oak_plank = load_asset("oak_plank", "models")
leave = load_asset("leaves", "models")



# audio
grass_audio = []
sand_audio = []
stone_audio = []
wood_audio = []

grass_audio.append(audio("grass1", "grass"))
grass_audio.append(audio("grass2", "grass"))
grass_audio.append(audio("grass3", "grass"))

sand_audio.append(audio("sand1", "sand"))
sand_audio.append(audio("sand2", "sand"))
sand_audio.append(audio("sand3", "sand"))

stone_audio.append(audio("stone1", "stone"))
stone_audio.append(audio("stone2", "stone"))
stone_audio.append(audio("stone3", "stone"))

wood_audio.append(audio("wood1", "wood"))
wood_audio.append(audio("wood2", "wood"))
wood_audio.append(audio("wood3", "wood"))

leaven = audio("cloth1", "cloth")



current_texture = grass

def update():
      global current_texture
      if held_keys['1']:
            current_texture = grass
      if held_keys['2']:
            current_texture = dirt
      if held_keys['3']:
            current_texture = oak
      if held_keys['4']:
            current_texture = sand
      if held_keys['5']:
            current_texture = stone
      if held_keys['6']:
            current_texture = oak_plank
      if held_keys['7']:
            current_texture = leave



class Hand(Entity):
      def __init__(self):
            super().__init__(
                  parent=camera.ui,
                  model='cube',
                  texture='white_cube',
                  scale=.5,
                  rotation = Vec3(-85, 145, 0),
                  position=Vec2(0.4, -0.5)
            )

      def update(self):
            self.texture = current_texture




                  
class BlockUI(Entity):
      def __init__(self):
            super().__init__(
                  parent=camera.ui,
                  model='cube',
                  scale=0.1,
                  texture=current_texture,
                  position=Vec2(-0.8, 0.4)
            )

      def update(self):
            self.texture = current_texture





class Sky(Entity):
      def __init__(self):
            super().__init__(
                  parent=scene,
                  model='sphere',
                  scale=150,
                  texture=sky,
                  double_sided=True
            )


class Voxel(Button):
      def __init__(self, position=(0, 0, 0), texture=None):
            super().__init__(
                  parent=scene,
                  position=position,
                  model='cube',
                  origin_y=.5,
                  texture=texture,
                  doublew_sided=True,
                  color=color.color(0, 0, 255),
                  highlight_color=color.gray
            )
      
      def input(self, key):
            if self.hovered:
                  if key == "right mouse down":
                        if current_texture == grass or current_texture == dirt:
                              voxel = Voxel(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(grass_audio))

                        if current_texture == sand:
                              voxel = Voxel(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(sand_audio))

                        if current_texture == stone:
                              voxel = Voxel(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(stone_audio))
                        
                        if current_texture == oak or current_texture == oak_plank:
                              voxel = Voxel(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(random.choice(wood_audio))

                        if current_texture == leave:
                              voxel = Voxel(position=self.position+mouse.normal, texture=current_texture)
                              mcoms.PlayAudio(leaven)
                  if key == "left mouse down":

                        if self.texture == grass:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(grass_audio))

                        elif self.texture == dirt:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(grass_audio))

                        elif self.texture == sand:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(sand_audio))

                        elif self.texture == oak or self.texture == oak_plank:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(wood_audio))

                        elif self.texture == stone:
                              destroy(self)
                              mcoms.PlayAudio(random.choice(stone_audio))

                        elif self.texture == leave:
                              destroy(self)
                              mcoms.PlayAudio(leaven)




for z in range(25):
      for x in range(25):
            voxel = Voxel((x, 0, z), texture=grass)









player = FirstPersonController()
sky_text = Sky()
blockUI = BlockUI()
hand = Hand()





app.run()