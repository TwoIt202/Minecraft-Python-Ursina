from ursina import *
from ursina.shaders.basic_lighting_shader import basic_lighting_shader

app = Ursina()

class Hand(Entity):
      def __init__(self, block='grass'):

            self.block = block

            super().__init__(
                  parent=camera.ui,
                  model='cube',
                  texture=load_texture(f"assets/{block}.png"),
                  scale=.5,
                  rotation = Vec3(-80, 145, 0),
                  position=Vec2(0.4, -0.5),
                  shader=basic_lighting_shader
            )
      
      def slab_on(self, mode, slot, allowed_blocks):
            if mode and slot in allowed_blocks: 
                  self.scale = (.5, .5, .25)
                  self.position = Vec2(0.4, -0.4)
            else: 
                  self.scale = (.5, .5, .5)
                  self.position = Vec2(0.4, -0.5)
