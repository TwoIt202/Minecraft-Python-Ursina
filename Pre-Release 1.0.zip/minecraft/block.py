from ursina import *
from minecraft.hand import Hand
from ursina.shaders.basic_lighting_shader import basic_lighting_shader

from random import randint
from perlin_noise import PerlinNoise
from math import dist



app = Ursina()
hand_block = Hand('grass')


class Block(Button):
    def __init__(self, position=(0, 0, 0), texture='assets/grass', current_slot='assets/grass', allow_slabs=False):


        self.type = texture
        self.pos = position
        self.current_slot = current_slot
        self.allow_slabs = allow_slabs
        self.hand = hand_block

        self.block_slabs = ['assets/stone', 'assets/cobblestone', 'assets/oak_plank']


        super().__init__(
            parent=scene,
            position=position,
            model='cube',
            texture=load_texture(self.type),
            color=color.white,
            highlight_color=color.gray,
            shader=basic_lighting_shader
        )

        if self.allow_slabs and self.current_slot in self.block_slabs:
              self.scale = (1, .5, 1)

        if isinstance(texture, Texture): self.texture = texture

    def input(self, key):
        if key == '1': self.current_slot = 'assets/grass'
        if key == '2': self.current_slot = 'assets/dirt'
        if key == '3': self.current_slot = 'assets/stone'
        if key == '4': self.current_slot = 'assets/cobblestone'
        if key == '5': self.current_slot = 'assets/sand'
        if key == '6': self.current_slot = 'assets/oak_log'
        if key == '7': self.current_slot = 'assets/oak_plank'
        if key == '8': self.current_slot = 'assets/leaves'
        # if key == '9': self.current_slot = 'assets/tnt'

        if isinstance(self.current_slot, Texture): self.current_slot = self.current_slot.path
        self.hand.texture = load_texture(self.current_slot)
        self.hand.slab_on(self.allow_slabs, self.current_slot, self.block_slabs)

        if key == 'r': 
            self.allow_slabs = not self.allow_slabs 
    

        if self.hovered:
            if key == 'left mouse down': 
                destroy(self)
                        

            if key == 'right mouse down' and self.allow_slabs and self.current_slot in self.block_slabs: 
                position = Vec3(self.position[0], self.position[1] - .25, self.position[2])
                Block(position + mouse.normal, self.current_slot, self.current_slot, self.allow_slabs)
            
            elif key == 'right mouse down' and self.allow_slabs and self.current_slot not in self.block_slabs: 
                position = Vec3(self.position[0], self.position[1], self.position[2])
                Block(position + mouse.normal, self.current_slot, self.current_slot, self.allow_slabs)

            elif key == 'right mouse down' and not self.allow_slabs: Block(self.position + mouse.normal, self.current_slot, self.current_slot, self.allow_slabs)

    



                            