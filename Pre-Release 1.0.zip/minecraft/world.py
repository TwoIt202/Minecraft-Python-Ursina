from ursina import *
from perlin_noise import PerlinNoise
from minecraft.block import Block
from random import randint, choice

app = Ursina()

# Useless class but it can help with modding new generation
class World:
    def __init__(self, blockclass=Block) -> None:
        self.world_size = 32

        self.seed = random.randint(1, 99999999)
        self.noise = PerlinNoise(octaves=2,seed=self.seed)
        self.fl = randint(10, 25)

        for x in range(self.world_size):
            for z in range(self.world_size):
                y_n = self.noise([x * 0.02, z * 0.02])
                y = math.floor(y_n * self.fl)

                blockclass((x, y, z), texture='assets/grass')