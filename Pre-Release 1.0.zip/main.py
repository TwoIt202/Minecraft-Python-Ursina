from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from os import listdir

from minecraft.sky import Sky
from minecraft.block import Block
from minecraft.world import World



if len(listdir('mods')) > 0:
    print("Mods imported: ")
    for mod in listdir('mods'): 
         
        try:
            exec(f"from mods.{mod}.lib import *")
            print(f"    - {mod}")
        except: continue


app = Ursina()
player = FirstPersonController()
player.gravity = 0

sky = Sky()
world = World(Block)

def update():
        if held_keys['space']: player.y += 0.05
        if held_keys['shift']: player.y -= 0.05

        if held_keys['control']:
            player.speed = 11
        else:
            player.speed = 5
        

app.run()
